# <font color=Black>Spartan Official Smart Contracts (Optional)</font>

These Spartan Network Official Smart Contracts are pre-deployed smart contracts managed by Spartan Network operators for performing different tasks. They are open to all end-users to call and execute. These smart contracts are also open-source on Spartan Network GitHub and can be used for developers to study as use cases. We welcome interested developers to deploy more commercial smart contracts for specific business models and scenarios.


<br/>
<br/>
<br/>