# <font color=Black>Get Access Information</font>

<br/>

Enter your email address and we will send you the access information of the Non-Cryptocurrency public chains.



<img src='img/getchainaccessinformation.png' style='width:600px;' alt='getchainaccessinformation' title='getchainaccessinformation'>


Select a chain you want to access, then input the email address and get the verification code. Then, click the **"Confirm"** button to submit your application.

Shortly, BSN Spartan Network Data Center Portal will notify you by email and you are able to access the BSN Spartan Network via the nodes provided by the Spartan Network data center. 




<br/>
<br/>
<br/>