# <font color=Black>Getting Started</font>

<script language="javascript">document.location='getaWalletAddress.html'</script>



<br/>
<br/>
<br/>