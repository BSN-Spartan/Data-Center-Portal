# <font color=Black>Spartan Official NFT Smart Contract</font>

<script language="javascript">document.location='nft721.html'</script>





<br/>
<br/>
<br/>