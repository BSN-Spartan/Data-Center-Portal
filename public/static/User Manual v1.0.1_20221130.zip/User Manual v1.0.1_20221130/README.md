<br/>
<br/>
<br/>



# <center><font color=Black>BSN Spartan Data Center Portal User Manual</font></center>

<br/>

#### <center><font color=Black>version 1.0.1</font></center>

#### <center><font color=Black>Nov. 30, 2022</font></center>

<br/>



#### <center><a href="../User Manual.pdf" style="text-decoration:underline;">Download PDF</a></center>



<br/>
<br/>
<br/>









