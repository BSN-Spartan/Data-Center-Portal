gitbook build
cp  _book\img\apple-touch-icon-precomposed-152.png _book\gitbook\images\apple-touch-icon-precomposed-152.png
cp  _book\img\favicon.ico _book\gitbook\images\favicon.ico