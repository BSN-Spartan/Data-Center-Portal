module.exports = {
  /**
   * data center url
   */
  baseURL: "data center url",  
};
